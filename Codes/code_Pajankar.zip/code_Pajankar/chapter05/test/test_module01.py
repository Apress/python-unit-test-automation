def test_case01():
	assert 'python'.upper() == 'PYTHON'
