class TestClass01:

	def test_case01(self):
		assert 'python'.upper() == 'PYTHON'

	def test_case02(self):
		assert 'PYTHON'.lower() == 'python'

