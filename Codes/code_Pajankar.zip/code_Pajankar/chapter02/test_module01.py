"""
This is test_module01.
This is example of multiline docstring.
"""


class TestClass01:
    """This is TestClass01."""

    def test_case01(self):
        """This is test_case01()."""


def test_function01():
    """This is test_function01()."""

