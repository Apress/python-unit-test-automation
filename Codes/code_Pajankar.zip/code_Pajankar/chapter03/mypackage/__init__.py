all = ["mymathlib", "mymathsimple"]

