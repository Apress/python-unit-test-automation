import unittest


class TestClass14(unittest.TestCase):
    def test_case01(self):
        raise Exception
