def test_case01():
	assert 'aaa'.upper() == 'AAA'
